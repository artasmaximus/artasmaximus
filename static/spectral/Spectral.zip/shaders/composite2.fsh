#version 330 compatibility
// Pass 3: tone map the linear HDR scene, then split it into a low band (broad
// color) and a high band (detail), soften the low band toward paint, and lay
// the detail back on with its overshoot clamped so edges never halo.

#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform sampler2D colortex0;
uniform sampler2D colortex2;

in vec2 texcoord;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 outColor;

// Filmic curve (Narkowicz's ACES fit), then back to display gamma.
vec3 tonemap(vec3 x) {
	x *= EXPOSURE;
	x = clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0);
	return pow(x, vec3(1.0 / 2.2));
}

vec3 saturate3(vec3 c, float s) {
	return mix(vec3(luma(c)), c, s);
}

void main() {
	vec3 color = tonemap(texture(colortex0, texcoord).rgb);
#ifdef BAND_SPLIT
	vec3 low = tonemap(texture(colortex2, texcoord).rgb);
	vec3 high = clamp(color - low, -HALO, HALO);

	// Soft posterize: brightness eases between levels instead of stepping, and
	// only PAINT of it is applied, so flat areas never break into blobs.
	float l = luma(low);
	float t = l * float(BAND_LEVELS);
	float lq = (floor(t) + smoothstep(0.3, 0.7, fract(t))) / float(BAND_LEVELS);
	vec3 paint = mix(low, low * (lq / max(l, 1e-4)), PAINT);

	vec3 tint = mix(vec3(0.92, 0.97, 1.08), vec3(1.06, 1.0, 0.92), clamp(lq, 0.0, 1.0));
	paint = mix(paint, paint * tint, GRADE);

	color = paint + high * EDGE_GAIN;
	// Ink only on the dark side of an edge, as a pen line would sit.
	color *= 1.0 - INK * smoothstep(0.01, 0.05, -luma(high));
#endif
	color = saturate3(color, SATURATION);
	outColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}
