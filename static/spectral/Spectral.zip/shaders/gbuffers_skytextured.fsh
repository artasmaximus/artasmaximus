#version 330 compatibility
#define USE_TEXTURE
#include "/lib/gbuffer.fsh"
