#version 330 compatibility
// Pass 1: horizontal Gaussian (low-pass) of the scene into colortex1.

/*
const int colortex0Format = RGBA16F;
const int colortex1Format = RGBA16F;
const int colortex2Format = RGBA16F;
const int colortex3Format = RGBA16F;
*/

#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform sampler2D colortex0;
uniform float viewWidth;
uniform float viewHeight;

in vec2 texcoord;

/* RENDERTARGETS: 1 */
layout(location = 0) out vec4 outColor;

void main() {
#ifdef BAND_SPLIT
	outColor = vec4(blur1D(colortex0, texcoord, vec2(1.0 / viewWidth, 0.0), BAND_SIGMA), 1.0);
#else
	outColor = vec4(0.0);
#endif
}
