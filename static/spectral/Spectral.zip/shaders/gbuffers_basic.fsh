#version 330 compatibility
#define USE_LIGHTMAP
#define USE_FOG
#include "/lib/gbuffer.fsh"
