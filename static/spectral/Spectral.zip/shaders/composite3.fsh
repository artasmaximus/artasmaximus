#version 330 compatibility
// Pass 4: forward 8x8 DCT. Each pixel stores one coefficient of its block:
// pixel (u, v) inside the block holds frequency (u, v), like a JPEG encoder.

#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform sampler2D colortex0;
uniform float viewWidth;
uniform float viewHeight;

/* RENDERTARGETS: 3 */
layout(location = 0) out vec4 outColor;

void main() {
#ifdef DCT_COMPRESS
	ivec2 p = ivec2(gl_FragCoord.xy);
	ivec2 origin = (p / 8) * 8;
	ivec2 freq = p - origin;
	ivec2 lim = ivec2(viewWidth, viewHeight) - 1;

	vec3 sum = vec3(0.0);
	for (int y = 0; y < 8; y++) {
		float by = dctBasis(y, freq.y);
		for (int x = 0; x < 8; x++) {
			vec3 f = texelFetch(colortex0, min(origin + ivec2(x, y), lim), 0).rgb;
			sum += f * dctBasis(x, freq.x) * by;
		}
	}
	vec3 coef = 0.25 * dctC(freq.x) * dctC(freq.y) * sum;

	// Coarser steps for higher frequencies, as JPEG's quantization table does.
	float q = DCT_QUANT * (1.0 + float(freq.x + freq.y));
	if (q > 0.0) coef = floor(coef / q + 0.5) * q;

	outColor = vec4(coef, 1.0);
#else
	outColor = vec4(0.0);
#endif
}
