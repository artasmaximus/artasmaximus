#version 330 compatibility
// Final: radial ripple whose profile is a truncated Fourier series of a sawtooth,
// sum of sin(n x) / n. More terms give a sharper wavefront; the color channels
// are displaced by different amounts for a spectral fringe. Then a soft vignette.

#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform sampler2D colortex0;
uniform float viewWidth;
uniform float viewHeight;
uniform float frameTimeCounter;

in vec2 texcoord;

layout(location = 0) out vec4 outColor;

void main() {
	float aspect = viewWidth / viewHeight;
	vec2 d = texcoord - 0.5;
	d.x *= aspect;
	float r = length(d);

#ifdef RIPPLE
	float phase = r * RIPPLE_FREQ - frameTimeCounter * RIPPLE_SPEED;
	float wave = 0.0;
	for (int n = 1; n <= RIPPLE_TERMS; n++) wave += sin(float(n) * phase) / float(n);

	// Calm at the crosshair, fading out toward the edges.
	float fall = smoothstep(0.0, 0.15, r) * exp(-r * 1.5);
	vec2 dir = r > 0.0 ? d / r : vec2(0.0);
	dir.x /= aspect;
	vec2 off = dir * wave * RIPPLE_STRENGTH * fall;

	vec3 color = vec3(
		texture(colortex0, texcoord + off * (1.0 + 0.5 * CHROMA)).r,
		texture(colortex0, texcoord + off).g,
		texture(colortex0, texcoord + off * (1.0 - 0.5 * CHROMA)).b
	);
#else
	vec3 color = texture(colortex0, texcoord).rgb;
#endif

	color *= 1.0 - VIGNETTE * smoothstep(0.35, 1.0, r);
	outColor = vec4(color, 1.0);
}
