#version 330 compatibility
#define USE_TEXTURE
#define USE_FOG
#include "/lib/gbuffer.fsh"
