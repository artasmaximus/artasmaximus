// Shared fragment stage for the world. Everything is written in linear light so
// composite2 can tone map it; each program sets the USE_ defines it needs.
#include "/lib/settings.glsl"

uniform sampler2D gtexture;
uniform vec3 fogColor;
uniform float fogStart;
uniform float fogEnd;
uniform float alphaTestRef;
uniform vec4 entityColor;
uniform float sunAngle;
uniform float rainStrength;
uniform float nightVision;

in vec2 texcoord;
in vec2 lmcoord;
in vec4 glcolor;
in float viewDist;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 outColor;

vec3 toLinear(vec3 c) {
	return pow(c, vec3(2.2));
}

float luma(vec3 c) {
	return dot(c, vec3(0.2126, 0.7152, 0.0722));
}

#ifdef USE_LIGHTMAP
// Light color from the two lightmap channels. Vanilla tints both with one gray
// curve; here the sky channel follows the sun (warm low sun, white noon, blue
// moon) and the block channel is warm, so hue and saturation change with the light.
vec3 lightColor(vec2 lm) {
	lm = clamp((lm - 1.0 / 32.0) * 16.0 / 15.0, 0.0, 1.0);
	float sunHeight = sin(sunAngle * 6.2831853);
	float day = smoothstep(-0.12, 0.12, sunHeight);
	float lowSun = 1.0 - smoothstep(0.0, 0.45, abs(sunHeight));

	vec3 noon = vec3(1.0, 0.97, 0.92);
	vec3 golden = mix(noon, vec3(1.0, 0.62, 0.36), SUN_WARMTH);
	vec3 sun = mix(noon, golden, lowSun) * mix(1.0, 0.55, rainStrength);
	vec3 moon = mix(vec3(0.12), vec3(0.07, 0.10, 0.20), NIGHT_BLUE);
	vec3 sky = mix(moon, sun, day) * pow(lm.y, 2.4);

	vec3 torchHue = mix(vec3(1.0, 0.9, 0.8), vec3(1.0, 0.58, 0.28), TORCH_WARMTH);
	vec3 torch = torchHue * pow(lm.x, 2.2) * 1.4;

	vec3 ambient = vec3(0.020, 0.024, 0.032);
	return max(sky + torch + ambient, vec3(nightVision * 0.6));
}
#endif

void main() {
#ifdef USE_TEXTURE
	vec4 color = texture(gtexture, texcoord) * glcolor;
#else
	vec4 color = glcolor;
#endif
	if (color.a < max(alphaTestRef, 0.004)) discard;
	color.rgb = toLinear(color.rgb);

#ifdef USE_LIGHTMAP
	color.rgb = mix(color.rgb, toLinear(entityColor.rgb), entityColor.a);
	vec3 light = lightColor(lmcoord);
	color.rgb *= light;
	// In dim light the eye loses color first and shifts toward blue (the Purkinje effect).
	float dim = 1.0 - smoothstep(0.02, 0.3, luma(light));
	color.rgb = mix(color.rgb, luma(color.rgb) * vec3(0.8, 0.9, 1.2), dim * 0.55);
#endif

#ifdef USE_FOG
	float fog = clamp((viewDist - fogStart) / max(fogEnd - fogStart, 1e-3), 0.0, 1.0);
	color.rgb = mix(color.rgb, toLinear(fogColor), fog);
#endif
	outColor = color;
}
