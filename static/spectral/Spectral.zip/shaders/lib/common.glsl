const float PI = 3.14159265;

float luma(vec3 c) {
	return dot(c, vec3(0.2126, 0.7152, 0.0722));
}

// One axis of a Gaussian blur, +-3 sigma in 25 taps. Linear filtering fills the gaps.
// A Gaussian is a low-pass filter: its Fourier transform is another Gaussian.
vec3 blur1D(sampler2D tex, vec2 uv, vec2 texel, float sigma) {
	vec3 sum = vec3(0.0);
	float total = 0.0;
	for (int i = -12; i <= 12; i++) {
		float x = float(i) * sigma * 0.25;
		float k = exp(-0.5 * x * x / (sigma * sigma));
		sum += texture(tex, uv + texel * x).rgb * k;
		total += k;
	}
	return sum / total;
}

// Orthonormal DCT-II weight for frequency index n.
float dctC(int n) {
	return n == 0 ? 0.70710678 : 1.0;
}

// Basis value for sample x (0-7) at frequency u (0-7) in an 8-point DCT.
float dctBasis(int x, int u) {
	return cos(float(2 * x + 1) * float(u) * PI / 16.0);
}
