// Spectral: post-processing in the frequency domain.
// Iris reads each bracketed list as the choices for that option.

// ---- Lighting: colored sky, sun, moon and torch light; filmic tone mapping ---
#define EXPOSURE 1.3 // [0.8 1.0 1.15 1.3 1.5 1.75 2.0]
#define SUN_WARMTH 1.0 // [0.0 0.5 1.0 1.5]
#define TORCH_WARMTH 1.0 // [0.0 0.5 1.0 1.5]
#define NIGHT_BLUE 1.0 // [0.0 0.5 1.0 1.5]
#define SATURATION 1.08 // [0.8 0.9 1.0 1.08 1.15 1.25]
#define VIGNETTE 0.25 // [0.0 0.15 0.25 0.4 0.6]

// ---- Band split: Gaussian low-pass, residual high-pass ----------------------
#define BAND_SPLIT
#define BAND_SIGMA 4.0 // [2.0 3.0 4.0 6.0 8.0 12.0 16.0]
#define PAINT 0.5 // [0.0 0.25 0.5 0.75 1.0]
#define BAND_LEVELS 8 // [3 4 5 6 8 12 16]
#define EDGE_GAIN 1.15 // [0.0 0.5 1.0 1.15 1.3 1.6 2.0 3.0]
#define HALO 0.05 // [0.02 0.05 0.1 0.2 1.0]
#define INK 0.2 // [0.0 0.1 0.2 0.35 0.5 0.75 1.0]
#define GRADE 0.4 // [0.0 0.2 0.4 0.6 1.0]

// ---- DCT: 8x8 block cosine transform, keep only the low frequencies ---------
//#define DCT_COMPRESS
#define DCT_KEEP 3 // [1 2 3 4 5 6 8]
#define DCT_QUANT 0.02 // [0.0 0.01 0.02 0.04 0.08]

// ---- Ripple: radial displacement built from a Fourier series ---------------
//#define RIPPLE
#define RIPPLE_TERMS 5 // [1 2 3 5 8 12]
#define RIPPLE_STRENGTH 0.002 // [0.001 0.002 0.004 0.008 0.016]
#define RIPPLE_FREQ 30.0 // [10.0 20.0 30.0 45.0 60.0]
#define RIPPLE_SPEED 1.5 // [0.0 0.5 1.0 1.5 3.0]
#define CHROMA 1.0 // [0.0 0.5 1.0 2.0]
