#version 330 compatibility
// Pass 2: vertical Gaussian, finishing the 2D low band in colortex2.

#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform sampler2D colortex1;
uniform float viewWidth;
uniform float viewHeight;

in vec2 texcoord;

/* RENDERTARGETS: 2 */
layout(location = 0) out vec4 outColor;

void main() {
#ifdef BAND_SPLIT
	outColor = vec4(blur1D(colortex1, texcoord, vec2(0.0, 1.0 / viewHeight), BAND_SIGMA), 1.0);
#else
	outColor = vec4(0.0);
#endif
}
