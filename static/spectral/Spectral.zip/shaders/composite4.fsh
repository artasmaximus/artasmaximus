#version 330 compatibility
// Pass 5: inverse DCT from only the lowest DCT_KEEP x DCT_KEEP frequencies of each block.

#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform sampler2D colortex0;
uniform sampler2D colortex3;
uniform float viewWidth;
uniform float viewHeight;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 outColor;

void main() {
	ivec2 p = ivec2(gl_FragCoord.xy);
#ifdef DCT_COMPRESS
	ivec2 origin = (p / 8) * 8;
	ivec2 xy = p - origin;
	ivec2 lim = ivec2(viewWidth, viewHeight) - 1;

	// A block cut off by the screen edge has lost some coefficients, so it passes through.
	if (any(greaterThan(origin + 7, lim))) {
		outColor = texelFetch(colortex0, p, 0);
		return;
	}

	vec3 f = vec3(0.0);
	for (int v = 0; v < DCT_KEEP; v++) {
		float bv = dctC(v) * dctBasis(xy.y, v);
		for (int u = 0; u < DCT_KEEP; u++) {
			vec3 coef = texelFetch(colortex3, min(origin + ivec2(u, v), lim), 0).rgb;
			f += coef * dctC(u) * dctBasis(xy.x, u) * bv;
		}
	}
	outColor = vec4(clamp(0.25 * f, 0.0, 1.0), 1.0);
#else
	outColor = texelFetch(colortex0, p, 0);
#endif
}
